﻿using Microsoft.Owin;
using Owin;

[assembly: OwinStartupAttribute(typeof(TOTP.Startup))]
namespace TOTP
{
    public partial class Startup
    {
        public void Configuration(IAppBuilder app)
        {
            ConfigureAuth(app);
        }
    }
}
